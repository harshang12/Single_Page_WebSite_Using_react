import React, { PureComponent } from 'react'

export default class Footer extends PureComponent {
  render() {
    return (
      <div>
      <div id='footer' class="container-fluid text-center">
      <h4>Thanks for visit our Web</h4>
      </div>
      </div>
    )
  }
}
